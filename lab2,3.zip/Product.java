public class Product{
    private String code;
    private String name;
    public double price;
    
    public Product(){
        this.code = "";
        this.name = "";
        this.price = 0.0;
    }
    public Product(String code, String name, double price){
        this.code = code;
        this.name = name;
        this.price = price;
    }
    public Product(String code, String name){
        this.code = code;
        this.name = name;
        this.price = 0.0;
    }
    public String getCode(){
        return code;
    }
    public String getName(){
        return name;
    }
    public void setName(String newName){
        this.name = newName;
    }
}