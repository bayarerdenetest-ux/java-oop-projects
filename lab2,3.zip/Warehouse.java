public class Warehouse{
    private Product product;
    public Warehouse(Product p){
        this.product = p;
    }
    public void showStock(){
        System.out.println(" aguulhiin medeelel ");
        System.out.println(" baraanii code: " + product.getCode());
        System.out.println(" baraanii ner: " + product.getName());
        System.out.println(" baraanii une: " + product.price + "$");
    }
    public void setProduct(Product newProduct){
        this.product = newProduct;
    }
}