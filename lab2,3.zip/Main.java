
public class Main{
    public static void main(String[] args){
        Product p1 = new Product("A101", "Laptop", 1200);
        
        Warehouse myWarehouse = new Warehouse(p1);
        myWarehouse.showStock();
        p1.price = 1100.00;
        System.out.println("\n une uurchlugdsunii daraa");
        myWarehouse.showStock();
        Product p2 = new Product("B202", "Smartphone", 800.00);
        myWarehouse.setProduct(p2);
        System.out.println(" baraag solisonii daraa ");
        myWarehouse.showStock();
    }
}