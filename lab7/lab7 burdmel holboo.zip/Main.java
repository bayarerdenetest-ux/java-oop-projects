import java.util.Scanner;

public class Main {
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("=== Агуулах систем ===\n");

        Address warehouseAddr = new Address("Сүхбаатарын 5", "Улаанбаатар", "Монгол", "14240");
        Warehouse warehouse = new Warehouse("Төв агуулах", warehouseAddr, 50);

        Category electronics = new Category("Электроник", "Цахилгаан бараа");
        Category food = new Category("Хүнс", "Хүнсний бараа");

        Address supAddr1 = new Address("Энхтайваны 10", "Улаанбаатар", "Монгол", "14200");
        Supplier supplier1 = new Supplier("Монгол Тех ХХК", "info@mongoltech.mn", supAddr1);
        Supplier supplier2 = new Supplier("Алтан Тариа", "order@altantaria.mn", supAddr1);

        warehouse.addProduct(new Product("Laptop", 1500000, 10, electronics, supplier1));
        warehouse.addProduct(new Product("Smartphone", 800000, 25, electronics, supplier1));
        warehouse.addProduct(new Product("Tablet", 600000, 15, electronics, supplier1));
        warehouse.addProduct(new Product("Гурил 1кг", 2500, 100, food, supplier2));
        warehouse.addProduct(new Product("Цагаан будаа 1кг", 3000, 80, food, supplier2));
        warehouse.addProduct(new Product("Элсэн чихэр 1кг", 2000, 120, food, supplier2));

        int choice;
        do {
            System.out.println("\n1. Захиалга хийх");
            System.out.println("0. Гарах");
            System.out.print("Сонголт: ");
            choice = Integer.parseInt(sc.nextLine());

            switch (choice) {
                case 1: createOrder(warehouse); break;
            }
        } while (choice != 0);
    }

    static void printWarehouse(Warehouse warehouse) {
        System.out.println("\n=== Агуулахын бараанууд ===");
        System.out.printf("%-5s %-20s %-15s %-10s %-10s%n", "№", "Нэр", "Ангилал", "Үнэ", "Үлдэгдэл");
        System.out.println("------------------------------------------------------------");
        for (int i = 0; i < warehouse.getCount(); i++) {
            Product p = warehouse.getProduct(i);
            System.out.printf("%-5d %-20s %-15s %-10.0f %-10d%n",
                i + 1, p.getName(), p.getCategory().getName(), p.getPrice(), p.getQuantity());
        }
        System.out.println("------------------------------------------------------------");
    }

    static void createOrder(Warehouse warehouse) {
        printWarehouse(warehouse);

        System.out.print("\nЗахиалгын дугаар: "); String orderId = sc.nextLine();
        System.out.print("Огноо (жж-сс-өө): "); String date = sc.nextLine();

        System.out.println("--- Хүргэлтийн хаяг ---");
        System.out.print("Гудамж: "); String street = sc.nextLine();
        System.out.print("Хот: "); String city = sc.nextLine();
        Address shippingAddr = new Address(street, city, "Монгол", "");

        Order order = new Order(orderId, date, shippingAddr, warehouse, 20);

        String cont;
        do {
            System.out.print("\nБарааны дугаар сонгоно уу (1-" + warehouse.getCount() + "): ");
            int idx = Integer.parseInt(sc.nextLine());
            if (idx < 1 || idx > warehouse.getCount()) {
                System.out.println("Буруу дугаар.");
            } else {
                Product p = warehouse.getProduct(idx - 1);
                System.out.print("Тоо ширхэг: ");
                int qty = Integer.parseInt(sc.nextLine());
                if (qty > p.getQuantity()) {
                    System.out.println("Үлдэгдэл хүрэлцэхгүй байна. Үлдэгдэл: " + p.getQuantity());
                } else {
                    if (!order.addItem(new OrderItem(p, qty))) {
                        System.out.println("Үлдэгдэл хүрэлцэхгүй байна.");
                    } else {
                        System.out.println(p.getName() + " нэмэгдлээ.");
                    }
                }
            }
            System.out.print("Дахин нэмэх үү? (t/u): ");
            cont = sc.nextLine();
        } while (cont.equalsIgnoreCase("t"));

        System.out.println("\n========== Захиалгын баримт ==========");
        System.out.println("Захиалгын дугаар : " + order.getOrderId());
        System.out.println("Огноо            : " + order.getOrderDate());
        System.out.println("Хүргэлтийн хаяг  : " + order.getShippingAddress());
        System.out.println("---------------------------------------");
        order.printItems();
        System.out.println("---------------------------------------");
        System.out.println("Нийт дүн         : " + order.getTotalAmount() + "₮");
        System.out.println("=======================================");
    }
}