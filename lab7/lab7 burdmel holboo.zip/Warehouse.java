public class Warehouse {
    private String name;
    private Address address;
    private Product[] products;
    private int count;

    public Warehouse(String name, Address address, int capacity) {
        this.name = name;
        this.address = address;
        this.products = new Product[capacity];
        this.count = 0;
    }

    public String getName() { return name; }
    public Address getAddress() { return address; }
    public int getCount() { return count; }

    public void setName(String name) { this.name = name; }
    public void setAddress(Address address) { this.address = address; }

    public void addProduct(Product product) {
        if (count < products.length) {
            products[count++] = product;
        }
    }

    public Product findProductByName(String name) {
        for (int i = 0; i < count; i++) {
            if (products[i].getName().equalsIgnoreCase(name)) return products[i];
        }
        return null;
    }

    public Product getMostExpensiveProduct() {
        if (count == 0) return null;
        Product most = products[0];
        for (int i = 1; i < count; i++) {
            if (products[i].getPrice() > most.getPrice()) most = products[i];
        }
        return most;
    }

    public Product[] getProductsByCategory(Category category) {
        Product[] temp = new Product[count];
        int idx = 0;
        for (int i = 0; i < count; i++) {
            if (products[i].getCategory().getName().equals(category.getName())) {
                temp[idx++] = products[i];
            }
        }
        Product[] result = new Product[idx];
        for (int i = 0; i < idx; i++) result[i] = temp[i];
        return result;
    }
    public Product getProduct(int index) {
        return products[index];
    }
    @Override
    public String toString() {
        return "Warehouse{name='" + name + "', address=" + address + ", productCount=" + count + "}";
    }
}