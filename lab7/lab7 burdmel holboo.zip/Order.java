public class Order {
    private String orderId;
    private String orderDate;
    private Address shippingAddress;
    private Warehouse warehouse;
    private OrderItem[] items;
    private int count;

    public Order(String orderId, String orderDate, Address shippingAddress, Warehouse warehouse, int capacity) {
        this.orderId = orderId;
        this.orderDate = orderDate;
        this.shippingAddress = shippingAddress;
        this.warehouse = warehouse;
        this.items = new OrderItem[capacity];
        this.count = 0;
    }

    public String getOrderId() { 
        return orderId; 
    }
    public String getOrderDate() { 
        return orderDate; 
    }
    public Address getShippingAddress() { 
        return shippingAddress; 
    }
    public Warehouse getWarehouse() { 
        return warehouse; 
    }
    public int getCount() { 
        return count; 
    }

    public void setShippingAddress(Address shippingAddress) { this.shippingAddress = shippingAddress; }
    public void setWarehouse(Warehouse warehouse) { this.warehouse = warehouse; }

    public boolean addItem(OrderItem item) {
        Product p = item.getProduct();
        if (item.getQuantity() > p.getQuantity()) {
        return false; 
        }
        p.setQuantity(p.getQuantity() - item.getQuantity()); 
        items[count++] = item;
        return true;
    }
    public double getTotalAmount() {
        double total = 0;
        for (int i = 0; i < count; i++) {
            total += items[i].getTotalPrice();
        }
        return total;
    }

    public OrderItem getLargestItem() {
        if (count == 0) return null;
        OrderItem largest = items[0];
        for (int i = 1; i < count; i++) {
            if (items[i].getTotalPrice() > largest.getTotalPrice()) largest = items[i];
        }
        return largest;
    }

    public void printItems() {
        for (int i = 0; i < count; i++) {
            System.out.println("  " + items[i]);
        }
    }

    @Override
    public String toString() {
        return "Order{id='" + orderId + "', date='" + orderDate +
               "', total=" + getTotalAmount() + ", items=" + count + "}";
    }
}