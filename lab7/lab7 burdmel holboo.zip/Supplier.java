public class Supplier {
    private String name;
    private String contactEmail;
    private Address address;

    public Supplier(String name, String contactEmail, Address address) { //obectiig parametereer butsaah 
        this.name = name;
        this.contactEmail = contactEmail;
        this.address = address;
    }

    public String getName() { return name; }
    public String getContactEmail() { return contactEmail; } //ene heseg butsaah
    public Address getAddress() { return address; }

    public void setName(String name) { this.name = name; }
    public void setContactEmail(String contactEmail) { this.contactEmail = contactEmail; }
    public void setAddress(Address address) { this.address = address; }

    @Override
    public String toString() {
        return "Supplier{name='" + name + "', email='" + contactEmail + "', address=" + address + "}";
    }
}