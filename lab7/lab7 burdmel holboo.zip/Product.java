public class Product {
    private String name;
    private double price;
    private int quantity;
    private Category category;
    private Supplier supplier;

    public Product(String name, double price, int quantity, Category category, Supplier supplier) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
        this.category = category;
        this.supplier = supplier;
    }

    public String getName() { 
        return name; 
    }
    public double getPrice() { return price; }
    public int getQuantity() { return quantity; }
    public Category getCategory() { return category; } // ene heseg butsaah
    public Supplier getSupplier() { return supplier; } // ene heseg butsaah

    public void setName(String name) { this.name = name; } // ene heseg
    public void setPrice(double price) { this.price = price; } //ene heseg onooh 
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public void setCategory(Category category) { this.category = category; }
    public void setSupplier(Supplier supplier) { this.supplier = supplier; }

    public boolean isAvailable() {
        return quantity > 0;
    }

    @Override
    public String toString() {
        return "Product{name='" + name + "', price=" + price + ", qty=" + quantity +
               ", category=" + category.getName() + ", supplier=" + supplier.getName() + "}";
    }
}