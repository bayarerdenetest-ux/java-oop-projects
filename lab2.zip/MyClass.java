public class MyClass {
    private Student оюутан; 

    public MyClass(Student s) {
        this.оюутан = s;
    }

    public void хэвлэх() {
        System.out.println("Энэ ангийн оюутан: " + оюутан.getName());
    }
}