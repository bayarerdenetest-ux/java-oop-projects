public class Student {
    private String нэр;

    public Student(String нэр) {
        this.нэр = нэр;
    }

    public String getName() {
        return нэр;
    }
}