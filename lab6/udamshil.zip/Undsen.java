public class Undsen {

    public static void main(String[] args) {

        System.out.println("===== baiguulagch 1 =====");
        Car car1 = new Car("Toyota", "tsagaan", 2020);
        car1.describe();
        car1.start();
        car1.honk();
        car1.fuelWarning();//1 uildel

        System.out.println("\n===== baiguulagch 2 =====");
        Car car2 = new Car("BMW", "har", 2023, 2, "Coupe");
        car2.describe();
        car2.start();
        car2.showCarInfo();
        car2.fuelWarning();
    }
}