public class Car extends Vehicle{
    private int doors;
    private String carType;//2 huviin ontslog
    
    public Car(String brand, String color, int year){//4
        super(brand, color, year);
        this.doors = 4;
        this.carType = "Sedan";
     
    }
    public Car(String brand, String color, int year, int doors, String carType) {//4 super this ashiglan
        this(brand, color, year);   
        this.doors   = doors;
        this.carType = carType;
    }
    public void honk() {
        System.out.println(brand + ": biib biib! ");//1 udamshuulj ashiglan
    }

    public void showCarInfo() {
        System.out.println("turul: " + carType + ", haalga: " + doors + " shirheg");
    }
    @Override
    public void describe() {
        super.describe();           
        System.out.println("  turul: " + carType + ", haalga " + doors + " shirheg");//3 etseg deer nemj baigaa
    }
    @Override
    public void start() {
        super.start();              
        System.out.println("  " + carType + " mahsin aslaa");
    }
}
