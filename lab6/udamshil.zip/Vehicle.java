public class Vehicle{
    protected String brand;
    protected String color;
    protected int year;
    
    public Vehicle(String brand, String color, int year){
        this.brand = brand;
        this.color = color;
        this.year = year;
    }
    public void describe(){
        System.out.println("brand: " +brand + " ungu: " + color + "on: " + year );
    }
    public void start(){
        System.out.println(brand + " asaj bain ");
    }
    public final void fuelWarning(){//5 hamgaalna
        System.out.println("tulshnii anhaaruulga");
    }
}