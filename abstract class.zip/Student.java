class Student extends UniversityMember{
    public boolean Login(String UserName, String Password){
        System.out.println("by student kod");
        return true;
    }
    public void Logout(){
        System.out.println("by student kod");
    }
}